<?php
include 'db.php';
if($session)
{

//Write your newsFeed logic

echo '{
  "updates": [
    {
      "user_id": "1",
      "username": "madhav",
      "name": "Bramha",
      "profile_pic": "http://demos.vetbossel.in/img/vetbossel.jpg",
      "update_id": "62",
      "user_update": "",
      "created": "1464062121",
      "commentCount": 2,
      "comments": [
        {
          "com_id": "72",
          "uid_fk": "221",
          "comment": "Quick learner",
          "created": "1469053420",
          "like_count": "0",
          "uploads": "http://demos.vetbossel.in/img/brother.jpg",
          "username": "Ramesh",
          "name": "madhav",
          "profile_pic": "http://demos.vetbossel.in/img/selva.jpg",
          "timeAgo": "2016-07-21T00:23:40+02:00"
        }
        ,
        {
          "com_id": "712",
          "uid_fk": "221",
          "comment": "Tamilan",
          "created": "1469053426",
          "like_count": "0",
          "uploads": "http://demos.vetbossel.in/img/vetbossel.jpg",
          "username": "sophia",
          "name": "Kamal",
          "profile_pic": "http://demos.vetbossel.in/img/kamal.jpg",
          "timeAgo": "2016-07-21T00:23:40+02:00"
        }
      ]
    },
 
  ]
}';

}

?>