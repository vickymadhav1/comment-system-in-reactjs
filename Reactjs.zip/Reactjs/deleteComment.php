<?php
include 'db.php';
if($_POST['updateID'] && $_POST['commentID']  && $session)
{
//Write Delete operation

echo true;
}


?>