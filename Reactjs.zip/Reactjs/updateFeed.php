<?php
include 'db.php';
if($_POST['user_update'] && $session)
{
$a="vetbossel";
$c="Vicky";
$b=$_POST['user_update'];
$t=time();
echo '{
  "updates": [
    {
      "user_id": "7",
      "username": "'.$a.'",
      "name": "'.$c.'",
      "update_id": "'.$t.'",
      "user_update": "'.$b.'",
      "created": "'.$t.'",
      "commentCount": 0,
      "comments": []
    }
  ]
}';
}

?>
