<?php
//Database Connection

//$session=$_SESSION['uid'];
$session=1;
?>