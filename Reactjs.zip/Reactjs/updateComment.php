<?php
include 'db.php';
if($_POST['user_comment'] && $_POST['updateID']  && $session)
{
$a="rajesh";
$b=$_POST['user_comment']; 
$d=$_POST['updateID']; 
$t=time();
echo '{
  "comments": [
    {
          "com_id": "'.$t.'",
          "uid_fk": "'.$d.'",
          "comment":"'.$b.'",
          "created": "'.$t.'",
          "like_count": "0",
          "uploads": "",
          "username": "vetbossel",
          "name": "Madhav",
          "timeAgo": "2016-07-18T21:50:27+02:00"
        }
  ]
}';

}

?>
