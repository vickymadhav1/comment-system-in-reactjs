<?php
include 'db.php';
if($_POST['updateID'] && $session)
{
//Write Delete operation

echo true;
}


?>